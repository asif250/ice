clc
clear all
close all
fm=5;
fc=100;
fcc=50;
A=1;
t=0:0.001:1;
m=(square(2*pi*fm*t)+1)/2;
c1=sin(2*pi*fc*t);
c2=sin(2*pi*fcc*t);
for i=0:1000
    if(m(i+1)==1)
        s(i+1)=c1(i+1);
    else
        s(i+1)=c2(i+1);
    end
end
for i=0:1000
    if(s(i+1)==c1(i+1))
        mm(i+1)=1;
    else
        mm(i+1)=0;
    end
end
subplot(511);
plot(t,m);
subplot(512);
plot(t,c1);
subplot(513);
plot(t,c2);
subplot(514);
plot(t,s);
subplot(515);
plot(t,mm);
        