clc
clear all
close all
d=[1 0 1 1 0 0 1 0 1 0]
ln=length(d);
t=0:0.001:1;
cc=cos(2*pi*t*ln);
cs=sin(2*pi*ln*t);
k=length(cc);
k1=k/ln;


for i=1:ln
    if(d(i)==0)
        d(i)=-1
        i=i+1;
    end
end
i=1;
j=1;
while(i<ln) && (j<ln)
    dd1(j)=d(i);
    dd1(j+1)=d(i);
    dd2(j)=d(i+1);
    dd2(j+1)=d(i+1);
    j=j+2;
    i=i+2;
end
t=1;
for i=1:ln
    for j=1:k1
        dd(t)=d(i);
        d1(t)=dd1(i);
        d2(t)=dd2(i);
        t=t+1;
        j=j+1;
    end
    i=i+1;
end
subplot(511);
plot(cc);
axis([0 t -2 2]);
subplot(512);
plot(cs);
axis([0 t -2 2]);
subplot(513);
stairs(dd);
axis([0 t -2 2]);
len=length(d1);
if(k<len)
   len=k;
end
for i=1:len
    qcc(i)=cc(i)*d1(i);
    qcs(i)=cs(i)*d2(i);
    i=i+1;
end
subplot(514);
plot(qcc);
axis([0 t -2 2]);
subplot(615);
plot(qcc);
axis([0 t -2 2]);
qp=qcc+qcs;
subplot(515);
plot(qp);
axis([0 t -2 2]);