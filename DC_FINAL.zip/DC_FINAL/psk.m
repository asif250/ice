clc 
close all 
clear all 
t=0:.001:1; 
fc=20;
fm=5;
amp=2;
c=amp.*sin(2*pi*fc*t);
subplot(4,1,1)
plot(t,c)

m=square(2*pi*fm*t);
subplot(4,1,2)
plot(t,m)

x=c.*m; 
subplot(4,1,3) 
plot(t,x)

xx=x./c; 
subplot(4,1,4) 
plot(t,xx)
