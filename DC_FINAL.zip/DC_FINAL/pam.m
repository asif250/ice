clc
close all
clear all
a=5;
f=3;
t=0:.01:1;
x1=1;
x2=a*sin(2*pi*f*t);
y=x1.*x2;
subplot(311);
stem(x1);
subplot(312);
plot(t,x2);
subplot(313);
stem(t,y);
