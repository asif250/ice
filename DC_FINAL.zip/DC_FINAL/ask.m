clc
clear all
close all
f=5;
a=2;
n=[1 0 1 0 1 0 1 1 0];
l=length(n);
subplot(4,1,1);
stairs(n);
 t=0:0.01:l;
y1=a*sin(2*pi*f*t);
subplot(4,1,2);
plot(t,y1);
for i=1:l
   for j=(i-1)*100:i*100
      if(n(i)==1)
          s(j+1)=y1(j+1);
         else
          s(j+1)=0;
       end
   end
end
subplot(4,1,3);
plot(t,s);
for i=1:l
  for j=(i-1)*100:i*100
   if(s(j+1)==y1(j+1))
      x(j+1)=1;
      else
       x(j+1)=0;
    end
  end
end

subplot(4,1,4);
plot(t,x);
