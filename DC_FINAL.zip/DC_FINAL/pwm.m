clc
clear all
close all
t=0:0.001:1;
fc=15;
fm=3;
a=7;
b=5;
vc=a.*sawtooth(2*pi*fc*t);
vm=b.*sin(2*pi*fm*t);
n=length(vc);
for i=1:n
    if(vm(i)>=vc(i))
        pwmm(i)=1;
    else
        pwmm(i)=0;
    end
end
subplot(311);
plot(t,vm);
subplot(312);
plot(t,vc);
subplot(313);
plot(t,pwmm);