function [y,n] = conv_m(x,nx,h,nh)
nyb=nx(1)+nh(1);
nye = nx(length(x)) + nh(length(h));
n=[nyb:nye];
y=conv(x,h);
end