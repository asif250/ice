
for a=-3:1:3
    if a>=0;
        b=1;
    else
        b=0;
    end
    
    for a=-3:3
        fprintf('%d ',a);
    end
    fprintf('\n');

    for a=-3:3
        fprintf('%d ',b);
    end



end
    fprintf('\n');
