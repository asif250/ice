function [y,n]=sigshift(x,m,k)
n=m+k;
y=x;
end