clc
clear all
close all
n0=0;
n1=-5;
n2=5;
[x,n]=stepseq(n0,n1,n2)
figure(1);
stem(n,x);
xlabel('n');
ylabel('x');
title('Unit Step Sequence');
grid on;