clc
clear all
close all
m=[-3:1:6]
x=[1 3 4 2 4 2 1 2 0 2]
n0= 3;
n1= -2;
subplot(3,1,1)
stem(m,x)
grid on
xlabel('time');
ylabel('amplitude');
title('Main signal');
[y1,n]=sigshift(x,m,n0);
subplot(3,1,2);
stem(n,y1)
xlabel('time');
ylabel('amplitude');
title('Shifting signal when n0 = 3');
grid on
[y2,n]=sigshift(x,m,n1);
subplot(3,1,3);
stem(n,y2)
xlabel('time');
ylabel('amplitude');
title('Shifting signal when n0 = -2');
grid on