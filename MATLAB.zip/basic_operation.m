clc
clear all
close all
n=[-3:1:6]
x1=[1 3 4 2 4 2 1 2 0 2]

subplot(4,2,1);
stem(n,x1)
xlabel('time');
ylabel('amplitude');
title('first signal');
x2=[2 4 3 2 0 3 0 1 3 1]
subplot(4,2,2);
stem(n,x2)
xlabel('time');
ylabel('amplitude');
title('second signal');
y1=x1+x2
subplot(4,1,2);
stem(n,y1)
xlabel('time');
ylabel('amplitude');
title('added signal');
y2=x1-x2
subplot(4,1,3);
stem(n,y2)
xlabel('time');
ylabel('amplitude');
title('Subtraced signal');
y3=x1.*x2
subplot(4,1,4);
stem(n,y3)
xlabel('time');
ylabel('amplitude');
title('multiplied signal');
grid on;
