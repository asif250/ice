clc
close all;
clear all;
fprintf('\n');
A=input(' Amplitude of Transmitting signal : ');
f=100;
T=1/f;
t=0:T/100:2*T;
y=A*sin(2*pi*f*t);
subplot(4,1,1);
plot(t,y,'linewidth',3);
ylabel(' Amplitude(volt) ')
xlabel('time(Sec)');
title(' Transmitting Signal ');
Ts=T/20;
Fs=1/Ts;
n=1:1:2*T/Ts;
y1=A*sin(2*pi*f*n*Ts);
subplot(4,1,2);
stem(n,y1);
ylabel(' Amplitude(volt) ')
xlabel('descrete time');
title(' Discrete Time signal Signal after sampling ');
y2=A+y1;
subplot(4,1,3);
stem(n,y2);
ylabel(' Amplitude(volt) ')
xlabel('descrete time');
title('DC Level + Discrete Time signal Signal ');
y3=round(y2);
subplot(4,1,4);
stem(n,y3);
ylabel(' Amplitude(volt) ')
xlabel('descrete time');
title('Quantized signal  ');
y4=dec2bin(y3)