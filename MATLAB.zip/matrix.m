clc;
close all;
clear all;
a=zeros(3,3);
for i=1:16
    for j=1:16
    a(i,j)=i^3+j^3;
    end;
end;
disp(a)

    