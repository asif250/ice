clc
clear all
close all
n=[-10:1:10]
t=-0.1+0.3j;
x=exp(t*n)
subplot(5,2,1);
stem(n,x);
title('Original Signal');
ylabel('amplitude');
xlabel('n');
subplot(5,2,2);
stem(n,real(x));
title('Real part');
ylabel('amplitude');
xlabel('n');
subplot(5,2,3);
stem(n,imag(x));
title('Imaginary part');
ylabel('amplitude');
xlabel('n');
subplot(5,2,4);
stem(n,abs(x));
title('Absulate part');
ylabel('amplitude');
xlabel('n');
subplot(5,2,5);
stem(n,(180/pi)*angle(x));
title('Angle');
ylabel('amplitude');
xlabel('n');



