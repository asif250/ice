clc
clear all
close all
Xk=input('Enter X(K)=');
[N,M]=size(Xk);
if M~=1;
    Xk=Xk.';
    N=M;
end;
xn=zeros(N,1);
k=0:N-1;
for n=0:N-1;
    xn(n+1)=exp(j*2*pi*k*n/N)*Xk;
end;
xn=xn/N;
disp('x(n)=');
disp(xn);
plot(xn);
grid on;
plot(xn);
stem(k,xn);
xlabel('....>n');
ylabel('........>Magnitude');
title('IDEF OF A SEQUENCE');
