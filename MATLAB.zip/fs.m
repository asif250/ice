clc;clear all;clf;
x=linspace(0,1.5,1000);
f=0;
for n=1:2:200
 % First Plot Square Wave Function
 X=[0,0,0.5,0.5,1.0,1.0,1.5,1.5];
 Y=[0,1,1,-1,-1,1,1,0];
 line(X,Y,'color','r','linewidth',2)
 grid on;hold on;
 f=f+(4/(n*pi))*sin(2*pi*n*x);
 error=mean((abs(f)-1).^2);
 plot(x,f,'k','linewidth',2)
 title(['Square Wave FS Partial Sum: ',...
 'n = ',num2str(n),' Error = ',num2str(error)])
 pause
 if error<0.01
 break
 end
 clf
end 