
n=3;
y4=dec2bin(n)
