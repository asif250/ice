clc
close all
clear all
M=16;
N=16;
p=4;
q=4;
for i=1:M
    for j=1:N
    X(i,j)=i^3+j^3;
    end;
end;
L=length(X);
k=sqrt(L);


  for i=1:k:L
    for j=1:k:L
MAX=max(X(i:i+p-1,j:j+q-1)) ;
%disp(MAX)
MAX=max(MAX) ;
 a(i,j)=MAX;


%disp(MAX)

    end;
    end;




for i=1:L
for j=1:L
if MAX<= X(i,j);
MAX=X(i,j);
end
end
end

disp('The  matrix is =')
disp(X)




disp('The required matrix is =')
disp(a)
disp('The  Maximum value in a matrix is =')
disp(MAX);

