clc
clear all
close all
x=[3,11,7,0,-1,4,2]
nx=[-3:3]
h=[2,3,0,-5,2,1]
nh=[-1:4]
[y,n]=conv_m(x,nx,h,nh)
subplot(3,1,1);
stem(nx,x);
xlabel('time');
ylabel('amplitude');
title('Input signal');
grid on
subplot(3,1,2);
stem(nh,h);
xlabel('time');
ylabel('amplitude');
title('Impulse Signal');
grid on
subplot(3,1,3);
stem(n,y);
xlabel('time');
ylabel('amplitude');
title('Convoluting Signal');
grid on