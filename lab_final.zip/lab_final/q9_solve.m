clc
clear all
close all
N=256;
T=1/128;
k=0:N-1;
t=k*T;
f=0.25+2*sin(2*pi*5*k*T)+1*sin(2*pi*12.5*k*T)+1.5*sin(2*pi*20*k*T)+0.5*sin(2*pi*35*k*T);
subplot(2,1,1);
plot(t,f);
title('Signal sampled at 128Hz');
xlabel('time');
ylabel('amplitude');
F=fft(f);
magF=abs([F(1)/N,F(2:N/2)/(N/2)]);
hertz=k(1:N/2)*(1/(N*T));
subplot(2,1,2);
stem(hertz,magF);
title('Frequency Components');
xlabel('time');
ylabel('amplitude');


