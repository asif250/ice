clc
clear all
close all
f1=500;
f2=200;
T=5;
t=0:T/100:T;
y=cos(2*pi*f1*t)+cos(2*pi*f2*t);
plot(t,y);
