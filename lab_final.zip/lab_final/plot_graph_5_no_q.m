clc
clear all;
close all;
n1=-5;
n2=5;
p=2;
q=-4;
[y1,m1]=unit_sample(p,n1,n2);
[y2,m2]=unit_sample(q,n1,n2);
y=2*y1-y2
subplot(311);
stem(m1,y1);
subplot(312);
stem(m2,y2);
subplot(313);
stem(m1,y);