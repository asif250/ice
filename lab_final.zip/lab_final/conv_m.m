function[y,n]=conv_m(x,nx,h,nh)
n1=nx(1)+nh(1);
n2=nx(length(nx))+nh(length(nh));
n=[n1:n2];
y=conv(x,h);
end
