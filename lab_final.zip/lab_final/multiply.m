clc
clear all
close all
x1=[5 0 3 4 5]
n1=[-1:3]
x2=[0 1 3 5 1]
n2=[-2:2]
[y,n]=sigmult(x1,n1,x2,n2)
subplot(311);
stem(n1,x1);
subplot(312);
stem(n1,x2);
subplot(313);
stem(n,y);