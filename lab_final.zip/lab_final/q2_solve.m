clc
clear all
close all
x=[1:7,6:-1:1];
n=[-2:10];
[y1,p]=sigshift(x,n,5);
[y2,q]=sigshift(x,n,-4);
[y,m]=sigadd(2*y1,p,-3*y2,q);
subplot(211);
stem(n,x);
subplot(212);
stem(m,y);