clc
clear all
close all
k=2;
n=0:50;
c=-(1/12)+(pi/6)*i;
x=k*exp(c*n);
subplot(211);
stem(n,real(x));
subplot(212);
stem(n,imag(x));