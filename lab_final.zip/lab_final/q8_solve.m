clc
clear all
close all
