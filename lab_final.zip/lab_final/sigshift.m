function[y,n]=sigshift(x,m,k)
y=x;
n=m+k;
end