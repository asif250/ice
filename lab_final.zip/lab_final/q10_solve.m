clc
clear all
close all
fs=1000;
f=10;
t=0:1/fs:1;
y=sin(2*pi*f*t);
plot(t,y);