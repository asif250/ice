clc
clear all
close all
Xk=[6.0000 + 0.0000i  -1.0000 + 1.0000i 0.0000 - 0.0000i  -1.0000 - 1.0000i];
[N,M]=size(Xk);
if M~=1
    Xk=Xk.';
    N=M;
end
xn=zeros(N,1);
k=0:N-1;
for n=0:N-1;
    xn(n+1)=exp(j*2*pi*n*k/N)*Xk;
end
xn=xn/N;
disp(xn);
stem(k,abs(xn));