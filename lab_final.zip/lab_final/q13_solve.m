clc
clear all
close all
N=250;
ts=0.0001;
t=[0:N-1]*ts;
x=cos(2*pi*100*t)+cos(2*pi*500*t);
plot(t,x);