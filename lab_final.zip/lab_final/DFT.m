clc
clear all
close all
N=4;
x=[1 1 2 2];
n=[0:N-1];
k=[0:N-1];
Wn=exp(-j*2*pi/N);
nk=n'*k;
wNnk=Wn.^nk;
Xk=x*wNnk;
disp('Xk=');
disp(Xk);
mag=abs(Xk);
subplot(211);
stem(k,mag);
phs=angle(Xk);
subplot(212);
stem(k,phs);