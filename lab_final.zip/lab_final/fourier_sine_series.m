clc;
clear all;
close all;
x=linspace(0,1.5,1000)
