clc
clear all
close all
x=[1 2 3 4 5]
m=-1:3
[y,n]=sigfold(x,m)
subplot(211);
stem(m,x);
subplot(212);
stem(n,y);