clc
clear all
close all
f=-5:.01:5;
X=4*sinc(4*f);
subplot(311);
plot(f,X)
subplot(312);
plot(f,abs(X));
subplot(313);
plot(f,angle(X));