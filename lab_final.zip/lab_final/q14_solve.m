clc
clear all
close all
N=5;
x=[1:5];
n=[-1:3];
k=[0:N-1];
Wn=exp(-j*2*pi/N);
nk=n'*k;
wNnk=Wn.^nk;
Xk=x*wNnk;
disp('Xk=');
disp(Xk);
mag=abs(Xk);
subplot(211);
stem(k,mag);
phs=angle(Xk);
subplot(212);
stem(k,phs);