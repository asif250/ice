clc
clear all
close all
A=5;%input('Enter the amplitude of transmiting signal :'); %start generate tranmitting signal;
f=100;
T=1/f;
t=0:T/100:2*T;
y=A*sin(2*pi*f*t);
subplot(411);
plot(t,y); %end
Ts=T/20; % start Sampling
Fs=1/Ts;
n=1:1:2*T/Ts;
y1=A*sin(2*pi*f*n*Ts);
subplot(412);
stem(n,y1); %end
y2=A+y1;          %if needed,add dc level
subplot(413);
stem(n,y2)
y3=round(y2); % start Quantization 
subplot(414);
stem(n,y3); %end
y4=dec2bin(y3) %signal to digital convert





