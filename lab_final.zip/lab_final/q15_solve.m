clc
clear all
close all
w=[0:1:500]*pi/500;
H=exp(j*w)./(exp(j*w)-0.9*ones(1,501));
subplot(211);
plot(w/pi,abs(H));
subplot(212);
plot(w/pi,angle(H)/pi);