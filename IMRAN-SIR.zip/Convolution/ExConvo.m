%Linear convolution of two sequences
a=input('Enter the input sequence1=');
b=input('Enter the input sequence2=');
n1=length(a);
n2=length(b)
x=0:1:n1-1;
subplot(2,2,1), stem(x,a);
title('INPUT SEQUENCE1');
xlabel('..........>n');
ylabel('......a(n)');
y=0:1:n2-1;
subplot(2,2,2), stem(y,b);
title('INPUT SEQUENCE2');
xlabel('..........>n');
ylabel('......>b(n)');
c=conv(a,b)
n3=0:1:n1+n2-2;
subplot(2,1,2), stem(n3,c);
title('CONVOLUTION OF TWO SEQUENCE1');
xlabel('..........>n');
ylabel('......c(n)');