%HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH
%signal basics-transmitting signal, sampling, Quantization Signal, Coding
%HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH



clc
close all;
clear all;

disp('XXXXXXXXXXXXXXXXXXXXXXXX Input function XXXXXXXXXXXXXXXXXXXXXXXXXXX');
%XXXXXXXXXXXXXXXXXXXXXXXXX INPUT FUNCTION XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
fprintf('\n');
A=input(' Amplitude of Transmitting signal : ');

fprintf('\n\n');






disp('XXXXXXXXXXXXXXXXXXXX Transmitting Function XXXXXXXXXXXXXXXXXXXXXXXXX');
% XXXXXXXXXXXXXXXXXXXXXXX transmitting signal generation XXXXXXXXXXXXXXXXXX
f=100;
T=1/f;
t=0:T/100:2*T;
y=A*sin(2*pi*f*t);
figure(1);
plot(t,y,'linewidth',3);
ylabel(' Amplitude(volt) ')
xlabel('time(Sec)');
title(' Transmitting Signal ');


%XXXXXXXXXXXXXXXXXXXXXXXXXXXXX sampling XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
Ts=T/20;
Fs=1/Ts;
n=1:1:2*T/Ts;
y1=A*sin(2*pi*f*n*Ts);
figure(2);
stem(n,y1);
ylabel(' Amplitude(volt) ')
xlabel('descrete time');
title(' Discrete Time signal Signal after sampling ');


%XXXXXXXXXXXXXXXXXXXXXXXXXXXX Aditional of DC Level XXXXXXXXXXXXXXXXXXXXXXX
y2=A+y1;
figure(3);
stem(n,y2);
ylabel(' Amplitude(volt) ')
xlabel('descrete time');
title('DC Level + Discrete Time signal Signal ');


%XXXXXXXXXXXXXXXXXXXXXXXXXXXX Quamtization Signal XXXXXXXXXXXXXXXXXXXXXXXXX
y3=round(y2);
figure(4);
stem(n,y3);
ylabel(' Amplitude(volt) ')
xlabel('descrete time');
title('Quantized signal  ');


%XXXXXXXXXXXXXXXXXXXX Binary information Generation XXXXXXXXXXXXXXXXXXXXXXX
y4=dec2bin(y3);
Bi=y4