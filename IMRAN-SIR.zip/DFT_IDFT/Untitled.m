%DFT of a sequence

x=1:5;
n=[-1:3];
k=[0:500];
wN=exp(-j*2*pi/500);
nk=n'*k;
wNnk=wN.^nk;
Xk=x*wNnk;
disp('Xk=');
disp(Xk);
mag=abs(Xk)
subplot(2,1,1);
plot(k,mag);
grid on;
xlabel('.......>k');
title('MAGNITUDE OF FOURIER TRANSFORM');
ylabel('Magnitude');
phase=angle(Xk)
subplot(2,1,2);
plot(k,phase);
grid on;
xlabel('.........>k');
title('PHASE OF FOURIER TRANSFORM');
ylabel('Phase');