%DFT of a sequence
N=input('Enter the length of sequence=');
x=input('Enter the sequence=');
n=[0:1:N-1];
k=[0:1:N-1];
wN=exp(-j*2*pi/N);
nk=n'*k;
wNnk=wN.^nk;
Xk=x*wNnk;
disp('Xk=');
disp(Xk);
mag=abs(Xk)
subplot(2,1,1);
stem(k,mag);
grid on;
xlabel('.......>k');
title('MAGNITUDE OF FOURIER TRANSFORM');
ylabel('Magnitude');
phase=angle(Xk)
subplot(2,1,2);
stem(k,phase);
grid on;
xlabel('.........>k');
title('PHASE OF FOURIER TRANSFORM');
ylabel('Phase');